package processor;

import org.springframework.batch.item.ItemProcessor;

import model.User;

public class UserItemProcessor implements ItemProcessor<User, User> {

	public User process(User user) throws Exception {
		// TODO Auto-generated method stub
		return user;
	}

	}